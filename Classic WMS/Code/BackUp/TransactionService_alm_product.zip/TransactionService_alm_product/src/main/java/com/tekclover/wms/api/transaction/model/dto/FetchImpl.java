package com.tekclover.wms.api.transaction.model.dto;

import lombok.Data;

@Data
public class FetchImpl {

	private String companyCodeId;
	private String plantId;
	private String languageId;
	private String warehouseId;
	private Long lineNo;
	private String itemCode;
	private String preInboundNo;
	private String refDocNumber;
	private String batchSerialNumber;
	private String loginUserID;
}