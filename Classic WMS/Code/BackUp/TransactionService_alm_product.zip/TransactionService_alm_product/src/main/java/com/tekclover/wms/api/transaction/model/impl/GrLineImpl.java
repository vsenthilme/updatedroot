package com.tekclover.wms.api.transaction.model.impl;

import java.util.Date;

public interface GrLineImpl {

     Double getInventoryQuantity();
     String getBarcodeId();
     Double getCbm();
     String getCbmUnit();
     String getManufacturerCode();
     String getManufacturerName();
     String getOrigin();
     String getBrand();
     String getRejectType();
     String getRejectReason();
     Double getCbmQuantity();                                        //CBM per Quantity
     String getCompanyDescription();
     String getPlantDescription();
     String getWarehouseDescription();
     String getInterimStorageBin();
     String getStatusDescription();
     String getPurchaseOrderNumber();
     String getMiddlewareId();
     String getMiddlewareHeaderId();
     String getMiddlewareTable();
     String getManufacturerFullName();
     String getReferenceDocumentType();
     String getBranchCode();
     String getTransferOrderNo();
     String getIsCompleted();
     String getLanguageId();
     String getCompanyCode();
     String getPlantId();
     String getWarehouseId();
     String getPreInboundNo();
     String getRefDocNumber();
     String getGoodsReceiptNo();
     String getPalletCode();
     String getCaseCode();
     String getPackBarcodes();
     Long getLineNumber();
     String getItemCode();
     Long getInboundOrderTypeId();
     Long getVariantCode();
     String getVariantSubCode();
     String getBatchSerialNumber();
     Long getStockTypeId();
     Long getSpecialStockIndicatorId();
     String getStorageMethod();
     Long getStatusId();
     String getBusinessPartnerCode();
     String getContainerNo();
     String getInvoiceNo();
     String getItemDescription();
     String getManufacturerPartNo();
     String getHsnCode();
     String getVariantType();
     String getSpecificationActual();
     String getItemBarcode();
     Double getOrderQty();
     String getOrderUom();
     Double getGoodReceiptQty();
     String getGrUom();
     Double getAcceptedQty();
     Double getDamageQty();
     String getQuantityType();
     String getAssignedUserId();
     String getPutAwayHandlingEquipment();
     Double getConfirmedQty();
     Double getRemainingQty();
     String getReferenceOrderNo();
     Double getReferenceOrderQty();
     Double getCrossDockAllocationQty();
     Date getManufacturerDate();
     Date getExpiryDate();
     Double getStorageQty();
     String getRemark();
     String getReferenceField1();
     String getReferenceField2();
     String getReferenceField3();
     String getReferenceField4();
     String getReferenceField5();
     String getReferenceField6();
     String getReferenceField7();
     String getReferenceField8();
     String getReferenceField9();
     String getReferenceField10();
     Long getDeletionIndicator();
     String getCreatedBy();
     Date getCreatedOn();
     String getUpdatedBy();
     Date getUpdatedOn();
     String getConfirmedBy();
     Date getConfirmedOn();

     // For Lead Time
     String getDiffDays();

     String getDiffHours();

     String getDiffMinutes();

     String getDiffSeconds();

}